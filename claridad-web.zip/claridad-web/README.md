# Claridad: tu web propia

Contenido: `public/posts.json`. Página: `public/index.html`. IA: `api/ai.js`.

## Publicarla (gratis, unos 15 minutos)
1. Crea cuentas en github.com y vercel.com (entra a Vercel con GitHub).
2. En GitHub, crea un repositorio nuevo y sube todo el contenido de esta carpeta (Add file > Upload files).
3. En Vercel: Add New > Project > elige tu repositorio > Deploy.
4. Consigue una clave de API en console.anthropic.com (Settings > API keys). Pon un límite de gasto mensual en Billing.
5. En Vercel: Project > Settings > Environment Variables. Agrega:
   - `ANTHROPIC_API_KEY` = tu clave
   - `DAILY_LIMIT` = 30 (opcional: usos de IA por persona al día)
6. Deployments > Redeploy. Tu web ya funciona con IA.
7. Dominio propio: Project > Settings > Domains.

## Editar contenido
En GitHub abre `public/posts.json`, pulsa el lápiz, edita y guarda. La web se actualiza sola en un minuto.
Cada post tiene: id, title, summary, cat, level, draft (true = oculto), theory, opinion, video, exercise.
Para listas en la teoría escribe cada punto como `1. Título: texto`. En el JSON, un salto de línea se escribe `\n`.
Video: pega un enlace de YouTube o Vimeo en `video`; en tu web sí se ve incrustado.
